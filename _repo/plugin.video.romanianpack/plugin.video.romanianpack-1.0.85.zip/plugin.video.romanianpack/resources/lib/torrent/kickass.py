# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'katcr.to'

class kickass:
    
    thumb = os.path.join(media, 'kickass.png')
    nextimage = next_icon
    searchimage = search_icon
    name = 'Kickass'
    menu = [('Recente', "https://%s/new/" % base_url, 'recente', thumb),
            ('Filme', "https://%s/movies/" % base_url, 'sortare', thumb),
            ('Seriale', "https://%s/tv/" % base_url, 'sortare', thumb),
            ('Anime', "https://%s/anime/" % base_url, 'sortare', thumb),
            ('XXX', "https://%s/xxx/" % base_url, 'sortare', thumb),
            ('Filme populare', "https://%s/popular-movies" % base_url, 'sortare', thumb),
            ('Seriale populare', "https://%s/popular-tv" % base_url, 'sortare', thumb),
            ('Anime populare', "https://%s/popular-anime/" % base_url, 'sortare', thumb),
            ('XXX populare', "https://%s/popular-xxx/" % base_url, 'sortare', thumb),
            ('Filme Top 100', "https://%s/top-100-movies" % base_url, 'get_torrent', thumb),
            ('Seriale Top 100', "https://%s/top-100-television" % base_url, 'get_torrent', thumb),
            ('Anime Top 100', "https://%s/top-100-anime" % base_url, 'get_torrent', thumb),
            ('XXX Top 100', "https://%s/top-100-xxx" % base_url, 'get_torrent', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    #def get_search_url(self, keyword):
        ##url = "https://%s/srch?search=%s" % (base_url, quote(keyword))
        ##url = "https://%s/sort-search/%s/seeders/desc/1/" % (base_url, quote(keyword))
        #return url
    sortare = [('Recent adăugate', '?sortby=time&sort=desc'),
               ('După seederi', '?sortby=seeders&sort=desc'),
               ('După Mărime', '?sortby=size&sort=desc'),
               ('După leecheri', '?sortby=leechers&sort=desc')]
    
    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        url = "https://%s/usearch/%s/?sortby=seeders&sort=desc" % (base_url, keyword)
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent')

    def parse_menu(self, url, meniu, info={}, torraction=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            accepted = ['Movies', 'TV', 'XXX']
            acceptcats = ['filmType', 'VideoType']
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                headers = {'Host': base_url, 'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1', 'Referer':'https://%s/' % base_url}
                link = fetchData(url, headers=headers)
                #log(link)
                if link:
                    infos = {}
                    regex = '''\<tr class=".+?"(.+?)\</tr\>'''
                    regex_tr = r'''href=".+?href="(.+?)"(?:.+?class="torType(.+?)".+?)?.+?\<a href=".+?html"\s+class=.+?k"\>(.+?)\</a\>.+?(?:.+?in\s+\<span.+?"\>(.+?)\</a\>.+?)?.+?\<td class="nobr center"\>(.+?)\</.+?\<td class="green center"\>([\dN\/A\s]+)\</td\>.+?\<td class="red lasttd center"\>([\dN\/A\s]+)\</td\>'''
                    for trr in re.findall(regex, link, re.IGNORECASE | re.DOTALL):
                        match = re.findall(regex_tr, trr, re.IGNORECASE | re.DOTALL)
                        if match:
                            for legatura, forum1, nume, forum, size, seeds, leechers in match:
                                forum = forum.strip()
                                forum1 = forum1.strip()
                                if forum in accepted or forum1 in acceptcats:
                                    legatura = unquote(re.sub(r'[htps://].+?/.+?\?url=', '', legatura))
                                    legatura = 'https://%s%s' % (base_url, legatura)
                                    nume = unescape(striphtml(nume)).strip()
                                    seeds = seeds.strip()
                                    leechers = leechers.strip()
                                    size = striphtml(size).strip()
                                    if seeds == 'N/A' : seeds = '0'
                                    if leechers == 'N/A': leechers = '0'
                                    nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (striphtml(nume), forum, size, seeds, leechers)
                                    size = formatsize(size)
                                    if not info:
                                        infos = {'Title': nume,
                                                'Plot': nume,
                                                'Size': size,
                                                'Poster': self.thumb}
                                    else:
                                        infos = info
                                        try:
                                            infos = eval(str(infos))
                                            infos['Size'] = size
                                            infos['Plot'] = '%s - %s' % (nume, infos['Plot'])
                                        except: pass
                                        #infos.update({'Plot': '%s - %s' % (nume, infos['Plot'])})
                                    lists.append((nume,legatura,self.thumb,'torrent_links', infos))
                    match = re.findall('(class="pages)', link, re.IGNORECASE)
                    if len(match) > 0:
                        if re.search("/(\d+)/", url): 
                            new = re.findall("/(\d+)/", url)
                            nexturl = re.sub('/(\d+)/', '/%s/' % (str(int(new[0]) + 1)), url)
                        else:
                            try:
                                newn = re.search(r'(.*)/\?(.*)',url)
                                nexturl = '%s/2/?%s' % (newn.group(1), newn.group(2))
                            except: 
                                nexturl = ('%s2/' % url) if url.endswith('/') else ''
                        lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append((nume,legatura,self.thumb,'get_torrent', info))
        elif meniu == 'torrent_links':
            headers = {'Host': base_url, 
                       'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                       'Referer':'https://%s/' % base_url}
            link = fetchData(url, headers=headers)
            turl = ''
            if link:
                torrent = re.findall('href="(magnet.+?)"', link)
                if torrent:
                    turl = torrent[0]
            action = torraction if torraction else ''
            if turl:
                openTorrent({'Tmode':torraction, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
              
