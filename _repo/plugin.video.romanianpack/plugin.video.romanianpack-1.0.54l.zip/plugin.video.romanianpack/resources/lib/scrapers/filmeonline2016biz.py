# -*- coding: utf-8 -*-
from resources.functions import *

base_url = 'https://www.filmeonline.st'

class filmeonline2016biz:
    
    thumb = os.path.join(media, 'filmeonline2016biz.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FilmeOnline2016.biz'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:57.0) Gecko/20100101 Firefox/57.0', 'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8', 'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3', 'TE': 'Trailers'}
        
    def get_search_url(self, keyword):
        url = base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente')

    def parse_menu(self, url, meniu, info={}):
        lists = []
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                link = fetchData(url, url, headers=self.headers)
                if not re.search(">Nothing Found", link):
                    regex_menu = '''<article.+?href="(.+?)".+?\s+src="(http.+?)".+?title">(.+?)<.+?"description">(.+?)</articl'''
                    if link:
                        match = re.findall(regex_menu, link, re.DOTALL | re.IGNORECASE)
                        for legatura, imagine, nume, descriere in match:
                            if not "&paged=" in legatura:
                                nume = htmlparser.HTMLParser().unescape(striphtml(nume).decode('utf-8')).encode('utf-8')
                                descriere = " ".join(htmlparser.HTMLParser().unescape(striphtml(descriere).decode('utf-8')).encode('utf-8').split())
                                info = {'Title': nume,'Plot': descriere,'Poster': imagine}
                                lists.append((nume, legatura, imagine, 'get_links', info))
                        match = re.compile('pagenavi', re.IGNORECASE).findall(link)
                        if len(match) > 0:
                            if '/page/' in url:
                                new = re.compile('/page/(\d+)').findall(url)
                                nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                            else:
                                if '/?s=' in url:
                                    nextpage = re.compile('\?s=(.+?)$').findall(url)
                                    nexturl = '%s%s?s=%s' % (base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                                else: nexturl = url + "/page/2"
                            lists.append(('Next', nexturl, self.nextimage, meniu, {}))
        elif meniu == 'get_links':
            import base64
            second = []
            link = fetchData(url, headers=self.headers)
            regex_java='''<script\s+src="(.+?/cache/.+?)"'''
            try:
                java = fetchData(re.findall(regex_java, link, re.IGNORECASE | re.DOTALL)[0], headers=self.headers)
                dataids = re.findall('(?:">(episodul.+?)<.+?)?data-id="(.+?)"', link, re.IGNORECASE | re.DOTALL)
                info = eval(info)
                infos = eval(str(info))
                for episod, ids in dataids:
                    if episod: 
                        lists.append(('[COLOR lime]%s[/COLOR]' % episod,'nolink','','nimic', {}))
                        infos['Episode'] = str(re.findall("episodul (\d+)$", episod, re.IGNORECASE)[0])
                    try:
                        year = re.findall("\((\d+)\)", infos.get('Title'))
                        infos['Year'] = year[0]
                    except: pass
                    try:
                        try:
                            infos['Season'] = str(re.findall("sezonul (\d+) ", info.get('Title'), re.IGNORECASE)[0])
                        except: infos['Season'] = '01'
                        if infos.get('Episode'):
                            infos['TvShowTitle'] = re.sub(" (?:–|\().+?\)", "", info.get('Title'))
                            infos['Title'] = '%s S%sE%s' % (infos['TvShowTitle'], infos['Season'].zfill(2), infos['Episode'].zfill(2))
                            infos['Plot'] = infos['Title'] + ' ' + info['Plot']
                    except: pass
                    ids = ids + '.+?atob\("(.+?)"'
                    playurl = base64.b64decode(re.findall(ids, java, re.IGNORECASE | re.DOTALL)[0])
                    host = playurl.split('/')[2].replace('www.', '').capitalize()
                    lists.append((host,playurl,'','play', str(infos), url))
            except: pass
        elif meniu == 'genuri':
            link = fetchData(url, headers=self.headers)
            regex_cats = '''categories-2"(.+?)</ul'''
            regex_cat = '''href="(.+?)"(?:\s+.+?)?>(.+?)<'''
            if link:
                for cat in re.findall(regex_cats, link, re.IGNORECASE | re.DOTALL):
                    match = re.findall(regex_cat, cat, re.IGNORECASE | re.DOTALL)
                    if len(match) >= 0:
                        for legatura, nume in sorted(match, key=self.getKey):
                            nume = clean_cat(htmlparser.HTMLParser().unescape(nume.decode('utf-8')).encode('utf-8')).capitalize()
                            lists.append((nume,legatura.replace('"', ''),'','recente', info))
        return lists
              
