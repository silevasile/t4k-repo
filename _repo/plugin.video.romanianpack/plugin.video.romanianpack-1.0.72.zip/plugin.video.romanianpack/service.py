# -*- coding: utf-8 -*-
from resources.lib.mrspservice import mrspService

mrspService().run()
