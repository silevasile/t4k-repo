# Copyright (c) The PyAMF Project.
# See LICENSE.txt for details.

"""
Remoting tests.

@since: 0.1.0
"""
